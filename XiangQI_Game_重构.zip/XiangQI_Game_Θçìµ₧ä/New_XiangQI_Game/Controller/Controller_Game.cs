﻿using System;
using Model;
using View;
namespace Controller
{
    public class Controller_Game
    {
        Pieces[,] board = new Pieces[10, 9];
        static int Position;

        //Initialized the Board with " - " Value
        //Which can avoid NULL REFERENCE EXCEPTION
        //Modified the Board
        //Without any return
        public static void Initialized_Board(Board board)
        {
            Pieces initializied = new initialized_piece("Empty", " - ", "Lost", true);
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    board.setPiece(i, j, initializied);
                }
            }

        }

        //Initialized All the Pieces in the XiangQi Game
        //Modified the Board
        //Without any return
        public static void Preperation_Board(Board board)
        {
            Pieces General_Red = new General("General", " 将", "Red", true);
            Pieces Advisor_Red_1 = new Advisor("Advisor", " 仕", "Red", true);
            Pieces Advisor_Red_2 = new Advisor("Advisor", " 仕", "Red", true);
            Pieces Elephant_Red_1 = new Elephant("Elephant", " 象", "Red", true);
            Pieces Elephant_Red_2 = new Elephant("Elephant", " 象", "Red", true);
            Pieces Horse_Red_1 = new Horse("Horse", " 马", "Red", true);
            Pieces Horse_Red_2 = new Horse("Horse", " 马", "Red", true);
            Pieces Rook_Red_1 = new Horse("Rook", " 车", "Red", true);
            Pieces Rook_Red_2 = new Horse("Rook", " 车", "Red", true);
            Pieces Cannon_Red_1 = new Cannon("Cannon", " 炮", "Red", true);
            Pieces Cannon_Red_2 = new Cannon("Cannon", " 炮", "Red", true);
            Pieces Soldier_Red_1 = new Horse("Soldier", " 兵", "Red", true);
            Pieces Soldier_Red_2 = new Horse("Soldier", " 兵", "Red", true);
            Pieces Soldier_Red_3 = new Horse("Soldier", " 兵", "Red", true);
            Pieces Soldier_Red_4 = new Horse("Soldier", " 兵", "Red", true);
            Pieces Soldier_Red_5 = new Horse("Soldier", " 兵", "Red", true);

            Pieces General_Black = new General("General", " 帅", "Black", true);
            Pieces Advisor_Black_1 = new Advisor("Adivisor", " 士", "Blackd", true);
            Pieces Advisor_Black_2 = new Advisor("Advisor", " 士", "Black", true);
            Pieces Elephant_Black_1 = new Elephant("Elephant", " 相", "Black", true);
            Pieces Elephant_Black_2 = new Elephant("Elephant", " 相", "Black", true);
            Pieces Horse_Black_1 = new Horse("Horse", " 马", "Black", true);
            Pieces Horse_Black_2 = new Horse("Horse", " 马", "Black", true);
            Pieces Rook_Black_1 = new Rook("Rook", " 车", "Black", true);
            Pieces Rook_Black_2 = new Rook("Rook", " 车", "Black", true);
            Pieces Cannon_Black_1 = new Cannon("Cannon", " 炮", "Black", true);
            Pieces Cannon_Black_2 = new Cannon("Cannon", " 炮", "Black", true);
            Pieces Soldier_Black_1 = new Soldier("Soldier", " 卒", "Black", true);
            Pieces Soldier_Black_2 = new Soldier("Soldier", " 卒", "Black", true);
            Pieces Soldier_Black_3 = new Soldier("Soldier", " 卒", "Black", true);
            Pieces Soldier_Black_4 = new Soldier("Soldier", " 卒", "Black", true);
            Pieces Soldier_Black_5 = new Soldier("Soldier", " 卒", "Black", true);


            //Initialized the GameBoard
            //Which Means that We Put All the Pieces Needed on the Board
            board.setPiece(0, 4, General_Red);
            board.setPiece(0, 3, Advisor_Red_1);
            board.setPiece(0, 5, Advisor_Red_2);
            board.setPiece(0, 2, Elephant_Red_1);
            board.setPiece(0, 6, Elephant_Red_2);
            board.setPiece(0, 1, Horse_Red_1);
            board.setPiece(0, 7, Horse_Red_2);
            board.setPiece(0, 0, Rook_Red_1);
            board.setPiece(0, 8, Rook_Red_2);
            board.setPiece(2, 1, Cannon_Red_1);
            board.setPiece(2, 7, Cannon_Red_2);
            board.setPiece(3, 0, Soldier_Red_1);
            board.setPiece(3, 2, Soldier_Red_2);
            board.setPiece(3, 4, Soldier_Red_3);
            board.setPiece(3, 6, Soldier_Red_4);
            board.setPiece(3, 8, Soldier_Red_5);

            board.setPiece(9, 4, General_Black);
            board.setPiece(9, 3, Advisor_Black_1);
            board.setPiece(9, 5, Advisor_Black_2);
            board.setPiece(9, 2, Elephant_Black_1);
            board.setPiece(9, 6, Elephant_Black_2);
            board.setPiece(9, 1, Horse_Black_1);
            board.setPiece(9, 7, Horse_Black_2);
            board.setPiece(9, 0, Rook_Black_1);
            board.setPiece(9, 8, Rook_Black_2);
            board.setPiece(7, 1, Cannon_Black_1);
            board.setPiece(7, 7, Cannon_Black_2);
            board.setPiece(6, 0, Soldier_Black_1);
            board.setPiece(6, 2, Soldier_Black_2);
            board.setPiece(6, 4, Soldier_Black_3);
            board.setPiece(6, 6, Soldier_Black_4);
            board.setPiece(6, 8, Soldier_Black_5);

        }

        static public int Get_Piece_Position(string Input)
        {
            Position = int.Parse(Input);

            return Position;
        }

        //Check the Usability of the Origin Point We Chosed
        static public bool check_Usability_Origin(Board board, string CurrentSide, int Cor_X, int Cor_Y)
        {
            bool Usability_Original = true;

            if (board.getPiece(Cor_X, Cor_Y).getSide() != CurrentSide || board.getPiece(Cor_X, Cor_Y).getType() == " - ")
            {
                Usability_Original = false;
            }
            return Usability_Original;
        }

        //Check the Usability of the Destination Point We Want to Move
        //If the Destination is the Same Side, then We cannot Move to that Position
        static public bool check_Usability_Destination(Board board, string CurrentSide, int Final_CorX, int Final_CorY)
        {
            bool Usability_Destination = true;

            if (board.getPiece(Final_CorX, Final_CorY).getSide() == CurrentSide)
            {
                Usability_Destination = false;
            }
            return Usability_Destination;
        }

        static public Pieces Select_Piece(Board board, int Cor_X, int Cor_Y)
        {
            Pieces Selected_Piece;
            Selected_Piece = board.getPiece(Cor_X, Cor_Y);

            return Selected_Piece;
        }

        static public void Move_Piece(int Cor_X, int Cor_Y, Board board, int Final_CorX, int Final_CorY)
        {
            Pieces initializied = new initialized_piece("Empty", " - ", "Lost", true);
            Pieces piece = Select_Piece(board, Cor_X, Cor_Y);
            //Recive the Result of the Rule
            //If it is obey the rule, then the Piece can be moved

            //We set the Piece We Chosed to the Destination
            board.setPiece(Final_CorX, Final_CorY, piece);
            //And we Set the Original Point to Empty
            board.setPiece(Cor_X, Cor_Y, initializied);


        }

        static public string Turn_Player_Side(int Round_Counter)
        {
            //When we have done one around
            //We Change the Player Side
            string CurrentSide;
            if (Round_Counter % 2 == 0)
            {
                CurrentSide = "Red";
            }
            else
            {
                CurrentSide = "Black";
            }
            return CurrentSide;
        }

        //判断出现问题，会出现，全局打印的情况
        //有的情况是正确打印的 有的情况出现打印错误的情况，甚至全部非棋子类都被打印
        static public void Detect_Possible_Move(int Cor_X, int Cor_Y, Board board)
        {
            for(int i = 0; i < 10; i++)
            {
                for(int j = 0; j < 9; j++)
                {
                    //被选中的棋子的Side，不能与目的地的Side相同
                    if(board.getPiece(Cor_X,Cor_Y).getSide() != board.getPiece(i, j).getSide())
                    {
                        //If CanMoveTo Method Return True
                        //Then We Set the Piece Status to False
                        if (Controller_Rules.CanMoveTo(Cor_X, Cor_Y, i, j, board))
                        {
                            board.getPiece(i, j).setStatus(false);
                        }
                    }
                    
                }
            }
        }

        //After We Detect the Possible Move
        //We Reset the Status of each Pieces to true, which is its origin status
        static public void Reset_All_Piece_Status(Board board)
        {
            for(int i = 0; i < 10; i ++)
            {
                for(int j = 0; j < 9; j++)
                {
                    board.getPiece(i, j).setStatus(true);
                }
            }
        }
    }
}
