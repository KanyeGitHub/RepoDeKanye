﻿using System;
using Model;
using View;

namespace Controller
{
    public class Controller_Rules
    {
        //Input the Piece We Chosed and the Destination We Want to Move and the Board
        //If this Method return true, then it can be Moved
        static public bool CanMoveTo(int CorX, int CorY,int Final_CorX, int Final_CorY, Board board)
        {
            Pieces piece = board.getPiece(CorX, CorY);
            string Type = piece.getType();
            string Represent = piece.getRepresent();
            int initial_location;
            int ending_location;
            int loop_Value;
            

            //If the Piece can Move, then the Ability To Move is True
            bool Ability_To_Move = true;

            switch (Represent)
            {
                case "General":
                    if (Type == "Red")
                    {
                        if (Final_CorY < 3 || Final_CorY > 5 || Final_CorX > 2)
                        {
                            Ability_To_Move = false;
                        }
                    }
                    else
                    {
                        if (Final_CorY < 3 || Final_CorY > 5 || Final_CorX < 7)
                        {
                            Ability_To_Move = false;
                        }
                    }

                    if ((Final_CorX - CorX) * (Final_CorX - CorX) + (Final_CorY - CorY) + (Final_CorY - CorY) != 1)
                    {
                        Ability_To_Move = false;
                    }

                    break;


                case "Advisor":
                    if (board.getPiece(CorX, CorY).getSide() == "Red")
                    {
                        if (Final_CorY < 3 || Final_CorY > 5 || Final_CorX > 2)
                        {
                            Ability_To_Move = false;
                        }
                    }
                    else
                    {
                        if (Final_CorY < 3 || Final_CorY > 5 || Final_CorX < 7)
                        {
                            Ability_To_Move = false;
                        }
                    }

                    if (Math.Abs(Final_CorX - CorX) != 1 || Math.Abs(Final_CorY - CorY) != 1)
                    {
                        Ability_To_Move = false;
                    }

                    break;

                case "Horse":
                    //马的移动，第一种情况，X为1，Y为2
                    if (Math.Abs(CorX - Final_CorX) == 1 && Math.Abs(CorY - Final_CorY) == 2)
                    {
                        if (board.getPiece(CorX, CorY + (Final_CorY - CorY) / Math.Abs(Final_CorY - CorY)).getSide() != "Lost")
                        {
                            Ability_To_Move = false;
                        }
                    }
                    //马的移动，第二种情况，X为2，Y为1
                    else if (Math.Abs(CorX - Final_CorX) == 2 && Math.Abs(CorY - Final_CorY) == 1)
                    {
                        if (board.getPiece(CorX + (Final_CorX - CorX) / Math.Abs(Final_CorX - CorX), CorY).getSide() != "Lost")
                        {
                            Ability_To_Move = false;
                        }
                    }
                    else
                    {
                        Ability_To_Move = false;
                    }

                    break;

                case "Elephant":
                    if (board.getPiece(CorX, CorY).getSide() == "Red")
                    {
                        if (Final_CorX > 4)
                        {
                            Ability_To_Move = false;
                        }
                    }
                    else
                    {
                        if (Final_CorX < 5)
                        {
                            Ability_To_Move = false;
                        }
                    }

                    if ((CorX - Final_CorX) * (CorX - Final_CorX) + (CorY - Final_CorY) * (CorY - Final_CorY) != 8)
                    {
                        Ability_To_Move = false;
                    }

                    if (board.getPiece((CorX + Final_CorX) / 2, (CorY + Final_CorY / 2)).getSide() != "Lost")
                    {
                        Ability_To_Move = false;
                    }

                    break;

                case "Soldier":
                    //If the Side is Red, It means that chesses are on the above of the board
                    //So we use the river to judge if the chess can go or not
                    if (board.getPiece(CorX, CorY).getSide() == "Red")
                    {

                        if (CorX < 5 && Final_CorX - CorX != 1)
                        {
                            Ability_To_Move = false;
                        }

                        if (CorX > 4)
                        {

                            if (CorX == Final_CorX && Math.Abs(CorY - Final_CorY) != 1)
                            {
                                Ability_To_Move = false;
                            }

                            if (CorY == Final_CorY && Math.Abs(CorX - Final_CorX) != 1)
                            {
                                Ability_To_Move = false;
                            }
                        }
                    }

                    if (board.getPiece(CorX, CorY).getSide() == "Black")
                    {
                        if (CorX > 4 && CorX - Final_CorX != 1)
                        {
                            Ability_To_Move = false;
                        }

                        if (CorX < 5)
                        {
                            if (CorX == Final_CorX && Math.Abs(CorY - Final_CorY) != 1)
                            {
                                Ability_To_Move = false;
                            }

                            if (CorY == Final_CorY && Math.Abs(CorX - Final_CorX) != 1)
                            {
                                Ability_To_Move = false;
                            }
                        }
                    }
                    break;

                case "Rook":
                    
                    //By the Properties of the Rook
                    //We first check that if the X is the same or Y
                    //If Both X and Y are not satisfied, then we return a false
                    if (CorX != Final_CorX && CorY != Final_CorY)
                    {
                        Ability_To_Move = false;
                    }

                    //If the CorX is same as the Final_CorX
                    //We try to get the Initial and Ending Point of the FOR loop
                    //And use the for loop to check the y Asix
                    if (CorX == Final_CorX)
                    {
                        //We get the interval of the for loop area.
                        //The interval is like :[CorX, Final_CorX]
                        initial_location = CorY < Final_CorY ? CorY : Final_CorY;
                        ending_location = CorY > Final_CorY ? CorY : Final_CorY;

                        for (loop_Value = initial_location + 1; loop_Value < ending_location; loop_Value++)
                        {
                            //If there exists one chess that is no "Lost"
                            //Then we return false, which means that it is not correct
                            if (board.getPiece(CorX, loop_Value).getType() != " - " || board.getPiece(Final_CorX, ending_location).getSide() == board.getPiece(CorX, CorY).getSide())
                            {
                                Ability_To_Move = false;
                            }
                        }
                    }

                    if (CorY == Final_CorY)
                    {
                        initial_location = CorX < Final_CorX ? CorX : Final_CorX;
                        ending_location = CorX > Final_CorX ? CorX : Final_CorX;

                        for (loop_Value = initial_location + 1; loop_Value < ending_location; loop_Value++)
                        {
                            if (board.getPiece(loop_Value, CorY).getType() != " - " || board.getPiece(ending_location, Final_CorY).getSide() == board.getPiece(CorX, CorY).getSide())
                            {
                                Ability_To_Move = false;
                            }
                        }
                    }
                    break;

                case "Cannon":

                    int Chess_Counter = 0;
                    //当X坐标相同时，我们要对Y进行循环，确定循环的起点和终点
                    if (CorX == Final_CorX)
                    {
                        //确定起点以及重点，引入一个新变量用于计算循环中出现的特定类型棋子个数
                        initial_location = CorY < Final_CorY ? CorY : Final_CorY;
                        ending_location = CorY > Final_CorY ? CorY : Final_CorY;
                        Chess_Counter = 0;

                        //如果有出现不为Lost的棋子，及有一个不为空的棋子，就计数 1
                        for (loop_Value = initial_location + 1; loop_Value < ending_location; loop_Value++)
                        {
                            if (board.getPiece(CorX, loop_Value).getType() != " - ")
                            {
                                Chess_Counter++;
                            }
                        }

                        //如果路径中间有多个不为空的棋子，这里明显无法走
                        if (Chess_Counter > 1)
                        {
                            Ability_To_Move = false;
                        }
                    }
                    //另外一种情况就是Y坐标相等的时候，这里我们对X进行循环，确定循环的起点和重点
                    else if (CorY == Final_CorY)
                    {
                        //确定起点终点等
                        initial_location = CorX < Final_CorX ? CorX : Final_CorX;
                        ending_location = CorX > Final_CorX ? CorX : Final_CorX;
                        Chess_Counter = 0;

                        for (loop_Value = initial_location + 1; loop_Value < ending_location; loop_Value++)
                        {
                            if (board.getPiece(loop_Value, CorY).getType() != " - ")
                            {
                                Chess_Counter++;
                            }

                            if (Chess_Counter > 1)
                            {
                                Ability_To_Move = false;
                            }
                        }
                    }
                    //如果X，Y都不相等，则返回false
                    else
                    {
                        Ability_To_Move = false;
                    }

                    if (Chess_Counter == 0 && board.getPiece(Final_CorX, Final_CorY).getType() != " - ")
                    {
                        Ability_To_Move = false;
                    }

                    if (Chess_Counter == 1 && board.getPiece(Final_CorX, Final_CorY).getType() == " - ")
                    {
                        Ability_To_Move = false;
                    }
                    break;
            }   
            return Ability_To_Move;
        }

        static public bool check_General_is_Over(Board board)
        {
            bool checkgame = true;
            int General_Counter = 0;

            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (board.getPiece(i, j).getRepresent() == "General")
                    {
                        General_Counter = General_Counter + 1;
                    }
                }
            }

            if (General_Counter != 2)
            {
                checkgame = false;
            }

            return checkgame;

        }



        public Controller_Rules(){}
    }
}
