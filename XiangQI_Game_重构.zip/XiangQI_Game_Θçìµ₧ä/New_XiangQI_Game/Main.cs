﻿using System;
using Model;
using View;
using Controller;

namespace New_XiangQI_Game
{
    class Program
    {
        static void Main(string[] args)
        {
            int Round_Counter = 0;
            string Input_X,Input_Y,Input_Final_X,Input_Final_Y;
            int Cor_X, Cor_Y, Final_CorX, Final_CorY;
            string CurrentSide;
            bool checkgame = true;
            //Create a Board

            Board board = new Board();

            //Use the Controller to Initialized the Board
            Controller_Game.Initialized_Board(board);
            //Use the Controller to Set Up the Board with All Pieces Needed
            Controller_Game.Preperation_Board(board);
            //Use the View to Display the Board We Just Set up
            View_Board.Display_Board(board);
            View_Board.Display_Welcome();

            while (checkgame)
            {
                CurrentSide = Controller_Game.Turn_Player_Side(Round_Counter);
                View_Board.Display_CurrentSide(CurrentSide);
                Controller_Game.Reset_All_Piece_Status(board);

                View_Board.Display_For_Select_Piece_X();
                Input_X = Console.ReadLine();
                Cor_X = Controller_Game.Get_Piece_Position(Input_X);

                View_Board.Display_For_Destinaton_Y();
                Input_Y = Console.ReadLine();
                Cor_Y = Controller_Game.Get_Piece_Position(Input_Y);

                if (!Controller_Game.check_Usability_Origin(board, CurrentSide, Cor_X, Cor_Y))
                {
                    View_Board.Display_Wrong_Origin();
                }

                while(Controller_Game.check_Usability_Origin(board, CurrentSide, Cor_X, Cor_Y))
                {
                    Controller_Game.Detect_Possible_Move(Cor_X, Cor_Y, board);
                    View_Board.Display_Possible_Move(board);

                    View_Board.Display_For_Destinaton_X();
                    Input_Final_X = Console.ReadLine();
                    Final_CorX = Controller_Game.Get_Piece_Position(Input_Final_X);

                    View_Board.Display_For_Destinaton_Y();
                    Input_Final_Y = Console.ReadLine();
                    Final_CorY = Controller_Game.Get_Piece_Position(Input_Final_Y);

                    if (!Controller_Game.check_Usability_Destination(board, CurrentSide, Final_CorX, Final_CorY))
                    {
                        View_Board.Display_Wrong_Destination();
                    }

                    while (Controller_Game.check_Usability_Destination(board, CurrentSide, Final_CorX, Final_CorY))
                    {
                        
                        if (Controller_Rules.CanMoveTo(Cor_X, Cor_Y,Final_CorX, Final_CorY,board))
                        {
                            Controller_Game.Move_Piece(Cor_X, Cor_Y, board, Final_CorX, Final_CorY);
                            View_Board.Display_Board(board);
                            checkgame = Controller_Rules.check_General_is_Over(board);
                            //If We Done One Operation,then We Update the Round Counter Value
                            Round_Counter++;
                            break;
                        }
                        else
                        {
                            View_Board.Display_Wrong_Destination();
                            break;
                        }
                    }
                    
                    break;
                }
            }
            View_Board.Display_GameOver();

        }

    }
}
