﻿using System;
using View;
using Controller;


namespace Model
{
    public class Board
    {
        Pieces[,] GameBoard = new Pieces[10, 9];

        public void setPiece(int CorX, int CorY, Pieces piece)
        {
            GameBoard[CorX, CorY] = piece;
        }

        public Pieces getPiece(int CorX, int CorY)
        {
            return GameBoard[CorX, CorY];
        }

        public Board() { }
    }

    
}
