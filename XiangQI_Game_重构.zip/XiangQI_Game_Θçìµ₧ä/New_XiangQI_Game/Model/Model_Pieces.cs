﻿using System;
using Model;
using View;

namespace Model
{
    public abstract class Pieces
    {
        string Type;
        string Side;
        bool Status;
        string Represent;

        public Pieces(string Represent,string Type,string Side,bool Status)
        {
            this.Represent = Represent;
            this.Type = Type;
            this.Side = Side;
            this.Status = Status;
        }

        //This Method May be Override Later
        public void CanMoveTo() { }

        public string getRepresent()
        {
            return this.Represent;
        }

        public string getType()
        {
            return this.Type;
        }

        public string getSide()
        {
            return this.Side;
        }

        public bool getStatus()
        {
            return this.Status;
        }

        public void setRepresent(string Represent)
        {
            this.Represent = Represent;
        }

        public void setType(string Type)
        {
            this.Type = Type;
        }

        public void setSide(string Side)
        {
            this.Side = Side;
        }

        public void setStatus(bool Status)
        {
            this.Status = Status;
        }
    }

    //The Initialized Piece is also one kind of the Pieces
    public class initialized_piece : Pieces
    {
        public initialized_piece(string Represent,string Type, string Side, bool Status)
            : base(Represent,Type, Side, Status) { }
    }

    public class General : Pieces
    {
        public  General(string Represent,string Type, string Side, bool Status)
            : base(Represent,Type, Side,Status)    {}
    }

    public class Horse : Pieces
    {
        public Horse(string Represent,string Type, string Side, bool Status)
            : base(Represent,Type, Side, Status)
        { }
    }

    public class Cannon : Pieces
    {
        public Cannon(string Represent,string Type, string Side, bool Status)
            : base(Represent,Type, Side, Status)
        { }
    }

    public class Advisor : Pieces
    {
        public Advisor(string Represent,string Type, string Side, bool Status)
            : base(Represent,Type, Side, Status)
        { }
    }

    public class Elephant : Pieces
    {
        public Elephant(string Represent,string Type, string Side, bool Status)
            : base(Represent,Type, Side, Status)
        { }
    }

    public class Soldier : Pieces
    {
        public Soldier(string Represent,string Type, string Side, bool Status)
            : base(Represent,Type, Side, Status)
        { }
    }

    public class Rook : Pieces
    {
        public Rook(string Represent,string Type, string Side, bool Status)
            : base(Represent,Type, Side, Status)
        { }
    }

}

