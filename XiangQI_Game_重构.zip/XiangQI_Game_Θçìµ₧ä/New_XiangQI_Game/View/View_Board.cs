﻿using System;
using Model;
using Controller;

namespace View
{
    public class View_Board
    {
        Pieces[,] board = new Pieces[10, 9];

        //If We Have the Board
        //Then We Can Use this Method to Display the Board
        static public void Display_Board(Board board)
        {
            Console.WriteLine();
            for(int i = 0; i < 10; i++)
            {
                for(int j = 0; j < 9; j++)
                {
                    Console.Write(board.getPiece(i,j).getType());
                }
                Console.WriteLine();
            }
        }

        static public void Display_Possible_Move(Board board)
        {
            
            for(int i = 0; i < 10; i++)
            {
                for(int j = 0; j < 9; j++)
                {
                    //False Means it can Move to the Position i,j
                    if(board.getPiece(i,j).getStatus() == false)
                    {
                        //Change the Console Display Color
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        //Use the Color We Set to Display the Type
                        Console.Write(board.getPiece(i, j).getType());
                        //Set Back the Color
                        Console.ForegroundColor = ConsoleColor.Black;
                    }
                    else
                    {
                        Console.Write(board.getPiece(i, j).getType());
                    }
                }
                Console.WriteLine();
            }
        }


        static public void Display_Wrong_Origin()
        {
            Console.WriteLine();
            Console.WriteLine(" You Have Chosen a Wrong Origin ! ");
        }

        static public void Display_Wrong_Destination()
        {
            Console.WriteLine();
            Console.WriteLine(" You Have Chosen a Wrong Destination ! ");
            Console.WriteLine();
            Console.WriteLine(" Please Retry ! ");
        }

        static public void Display_CurrentSide(string CurrentSide)
        {
            Console.WriteLine();
            Console.WriteLine("The Current Side is : " + CurrentSide);
        }

        static public void Display_Welcome()
        {
            Console.WriteLine();
            Console.WriteLine("---------- Welcome to the Xiang Qi Game ----------");
            Console.WriteLine();
            Console.WriteLine("Attention : The Side Above is the RED Side ！");
            Console.WriteLine();
        }

        //Display the Message for User to Input the Coordinate of the Selected Piece
        //And Return the Value of X and Y to the Controller
        static public void Display_For_Select_Piece_X()
        {
            Console.WriteLine();
            Console.WriteLine("Please Choose one of the Chess You Want to Move : ");
            Console.WriteLine();
            Console.WriteLine("Please Enter the Value of X : ");
        }

        
        static public void Display_For_Select_Piece_Y()
        {
            Console.WriteLine();
            Console.WriteLine("Please Enter the Value of Y : ");
        }


        //Display the Message For user to Input the Destination
        //And Return the Value of X and Y to the Controller
        static public void Display_For_Destinaton_X()
        {
            Console.WriteLine();
            Console.WriteLine("Please Choose the Destination You Want.");
            Console.WriteLine();
            Console.WriteLine("Please Enter the Value of X : ");
            
        }
        
        static public void Display_For_Destinaton_Y()
        {
            Console.WriteLine();
            Console.WriteLine("Please Enter the Value of Y : ");
            
        }

        static public void Display_GameOver()
        {
            Console.WriteLine();
            Console.WriteLine(" Your General is Dead ! ");
            Console.WriteLine(" Game Over ! ");
        }


        //Constructor
        public View_Board()
        {
        }

    }
}
