﻿using System;
namespace XiangQiGame_Console
{
    public class ChessBoard
    {

        ChessPiece[,] gameboard = new ChessPiece[10, 9];
        int CorX;
        int CorY;
        ChessPiece chess;

        //The Method is used to initial all the chess to " - "
        public void Initial_gameboard()
        {
            ChessPiece initial_chess = new ChessPiece(" - ", false, "Lost");

            for(int i = 0; i < 10; i++)
            {
                for(int j = 0; j < 9; j++)
                {
                    gameboard[i, j] = initial_chess;
                }
            }
        }

        //Get the Type of all the chess
        //And Display all the chess by a for loop
        public void Display_gameboard()
        {
            for(int i = 0; i < 10; i++)
            {
                for(int j = 0; j < 9; j++)
                {
                    Console.Write(gameboard[i, j].getType());
                }
                Console.WriteLine();
            }
        }

        public void setChess(int CorX, int CorY, ChessPiece chess)
        {
            gameboard[CorX, CorY] = chess;
        }

        public ChessPiece getChess(int CorX, int CorY)
        {
            return gameboard[CorX, CorY];
        }

    }
}
