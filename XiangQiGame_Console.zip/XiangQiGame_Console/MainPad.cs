﻿using System;
using XiangQiGame_Console.Qizi;

namespace XiangQiGame_Console
{
    class Program
    {
        //Preparation of the gameboard
        public static void Preparation_gameboard(ChessBoard board)
        {
            ChessPiece initial = new ChessPiece(" - ", false, "Lost");

            //Initialzing all the chess of the Red Side
            ChessPiece Red_General = new General(" 帅", true, "Red");
            ChessPiece Red_Rook_1 = new Rook(" 🚗", true, "Red");
            ChessPiece Red_Rook_2 = new Rook(" 🚗", true, "Red");
            ChessPiece Red_Advisor_1 = new Advisor(" 仕", true, "Red");
            ChessPiece Red_Advisor_2 = new Advisor(" 仕", true, "Red");
            ChessPiece Red_Cannon_1 = new Cannon(" 🚀", true, "Red");
            ChessPiece Red_Cannon_2 = new Cannon(" 🚀", true, "Red");
            ChessPiece Red_Horse_1 = new Horse(" 🐎", true, "Red");
            ChessPiece Red_Horse_2 = new Horse(" 🐎", true, "Red");
            ChessPiece Red_Elephant_1 = new Elephant(" 🐘", true, "Red");
            ChessPiece Red_Elephant_2 = new Elephant(" 🐘", true, "Red");
            ChessPiece Red_Soldier_1 = new Soldier(" 兵", true, "Red");
            ChessPiece Red_Soldier_2 = new Soldier(" 兵", true, "Red");
            ChessPiece Red_Soldier_3 = new Soldier(" 兵", true, "Red");
            ChessPiece Red_Soldier_4 = new Soldier(" 兵", true, "Red");
            ChessPiece Red_Soldier_5 = new Soldier(" 兵", true, "Red");

            ////Initialzing all the chess of the Black Side
            ChessPiece Black_General = new General(" 将", true, "Black");
            ChessPiece Black_Rook_1 = new Rook(" 🚓", true, "Black");
            ChessPiece Black_Rook_2 = new Rook(" 🚓", true, "Black");
            ChessPiece Black_Advisor_1 = new Advisor(" 士", true, "Black");
            ChessPiece Black_Advisor_2 = new Advisor(" 士", true, "Black");
            ChessPiece Black_Cannon_1 = new Cannon(" 💣", true, "Black");
            ChessPiece Black_Cannon_2 = new Cannon(" 💣", true, "Black");
            ChessPiece Black_Horse_1 = new Horse(" 🐕‍🦺", true, "Black");
            ChessPiece Black_Horse_2 = new Horse(" 🐕‍🦺", true, "Black");
            ChessPiece Black_Elephant_1 = new Elephant(" 🐘", true, "Black");
            ChessPiece Black_Elephant_2 = new Elephant(" 🐘", true, "Black");
            ChessPiece Black_Soldier_1 = new Soldier(" 卒", true, "Black");
            ChessPiece Black_Soldier_2 = new Soldier(" 卒", true, "Black");
            ChessPiece Black_Soldier_3 = new Soldier(" 卒", true, "Black");
            ChessPiece Black_Soldier_4 = new Soldier(" 卒", true, "Black");
            ChessPiece Black_Soldier_5 = new Soldier(" 卒", true, "Black");

            //Put the Red chess on the board
            board.setChess(0, 0, Red_Rook_1);
            board.setChess(0, 1, Red_Horse_1);
            board.setChess(0, 2, Red_Elephant_1);
            board.setChess(0, 3, Red_Advisor_1);
            board.setChess(0, 4, Red_General);
            board.setChess(0, 5, Red_Advisor_2);
            board.setChess(0, 6, Red_Elephant_2);
            board.setChess(0, 7, Red_Horse_2);
            board.setChess(0, 8, Red_Rook_2);
            board.setChess(2, 1, Red_Cannon_1);
            board.setChess(2, 7, Red_Cannon_2);
            board.setChess(3, 0, Red_Soldier_1);
            board.setChess(3, 2, Red_Soldier_2);
            board.setChess(3, 4, Red_Soldier_3);
            board.setChess(3, 6, Red_Soldier_4);
            board.setChess(3, 8, Red_Soldier_5);

            //Put the Black chess on the board
            board.setChess(9, 0, Black_Rook_1);
            board.setChess(9, 1, Black_Horse_1);
            board.setChess(9, 2, Black_Elephant_1);
            board.setChess(9, 3, Black_Advisor_1);
            board.setChess(9, 4, Black_General);
            board.setChess(9, 5, Black_Advisor_2);
            board.setChess(9, 6, Black_Elephant_2);
            board.setChess(9, 7, Black_Horse_2);
            board.setChess(9, 8, Black_Rook_2);
            board.setChess(7, 1, Black_Cannon_1);
            board.setChess(7, 7, Black_Cannon_2);
            board.setChess(6, 0, Black_Soldier_1);
            board.setChess(6, 2, Black_Soldier_2);
            board.setChess(6, 4, Black_Soldier_3);
            board.setChess(6, 6, Black_Soldier_4);
            board.setChess(6, 8, Black_Soldier_5);
        }

        //Use the roundCounter to check the current play side
        public static string checkCurrentSide(int RoundCounter)
        {
            string CurrentSide = "Black" ;
            if(RoundCounter % 2 == 0)
            {
                CurrentSide = "Red";
            }
            
            return CurrentSide;
        }

        //To Check if the user choose the real chess
        //Not a " - " default chess
        public static bool checkUsability_Original(ChessPiece Chess_Chosen,string CurrentSide)
        {
            bool Usability = false;
            //If it is Lost (Empty) or If it is the Wrong Side
            if(Chess_Chosen.getSide() == CurrentSide)
            {
                Usability = true;
            }

            return Usability;
        }

        //To check if the Destination is avalible or not
        public static bool checkUsability_Desination(ChessPiece Chess_Chosen, int Final_CorX, int Final_CorY, ChessBoard board)
        {
            string Side_Chess_Chosen;
            string Side_Destination_Chosen;
            Side_Chess_Chosen = Chess_Chosen.getSide();
            Side_Destination_Chosen = board.getChess(Final_CorX, Final_CorY).getSide();

            //If the Destination has the same type as the chosen chess
            //Then it is Wrong, we return a false
            //If the Destination has the "Lost" or the Other Sides
            //It is both OK for the operation
            if(Side_Chess_Chosen == Side_Destination_Chosen)
            {
                return false;
            }
            else
            {
                return true;
            }
            
        }

        public static bool checkGame_Is_Over(ChessBoard board)
        {
            int General_Counter = 0;
            for(int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (board.getChess(i, j).getType() == " 相" || board.getChess(i,j).getType() == " 将"){
                        General_Counter++;
                    }
                }
            }

            if(General_Counter == 2)
            {
                return true;
            }

            else
            {
                return false;
            }
        }


        //这里可以应用Console CleanLine 用于清楚控制台，避免从头到尾重复太多，难以分别
        static void Main(string[] args)
        {
            string Input_X;
            string Input_Y;
            string CurrentType;
            string CurrentSide;
            int CorX;
            int CorY;
            int Final_CorX;
            int Final_CorY;
            int RoundCounter = 0;
            ChessPiece Chess_Chosen;

            //Set the initial state of the game
            bool checkgame = true;

            //Set the initial Chess for later use
            ChessPiece initial = new ChessPiece(" - ", false, "Lost");

            //Set the Board and Initialzied the Board with " - "
            ChessBoard board = new ChessBoard();
            board.Initial_gameboard();

            ChessBoard Predict_board = new ChessBoard();
            Predict_board.Initial_gameboard();

            //Prepare the whole gameboard
            //Ready to Play
            Preparation_gameboard(Predict_board);
            Preparation_gameboard(board);
            board.Display_gameboard();
            Console.WriteLine();

            Console.WriteLine(" ---------- Welcome to the XiangQi Game ---------- ");
            Console.WriteLine();
            Console.WriteLine("Now, Choose One of the Chess You Want to Move. ");

            //Belows are the playing process
            while (checkgame)
            {
                try
                {
                    CurrentSide = checkCurrentSide(RoundCounter);
                    Console.WriteLine();
                    Console.WriteLine("The Current Side is : " + CurrentSide);
                   
                    Console.WriteLine("Reminder : The Red Side is the above Side.");
                    Console.WriteLine();

                    Console.WriteLine("Plese Enter the Corrdinate of the Chess.");
                    Console.WriteLine("Please Enter the Value of X : ");
                    Input_X = Console.ReadLine();
                    CorX = int.Parse(Input_X);

                    Console.WriteLine("Please Enter the Value of Y : ");
                    Input_Y = Console.ReadLine();
                    CorY = int.Parse(Input_Y);

                    //According to the Corrdinate inputed
                    //First get the Chess of that location
                    Chess_Chosen = board.getChess(CorX, CorY);

                    //If it is empty ("Lost") or wrong side, then print wrong
                    if (!checkUsability_Original(Chess_Chosen, CurrentSide))
                    {
                        Console.WriteLine();
                        Console.WriteLine("What You Have Chosen is Incorrect.");
                    }

                    //这里我们添加一个用于预测可以行进的地方的方法
                    //这里的BUG很多，判断路径 经常出现错误
                    if (checkUsability_Original(Chess_Chosen, CurrentSide))
                    {
                        //Set the Piece for predict usage
                        ChessPiece Predict_Chess = new ChessPiece(" 🔹", true, "Predict");
                        string Chosen_Type = Predict_board.getChess(CorX,CorY).getType();
                        

                        for(int i = 0; i < 10; i++)
                        {
                            for(int j = 0; j < 9; j++)
                            {
                                if(Chosen_Type == " 🚗" || Chosen_Type == " 🚓")
                                {
                                    if (Chess_Chosen.Judge_Rook_Can_MoveTo(CorX, CorY, i, j, board) && Chess_Chosen.getSide() != Predict_board.getChess(i, j).getSide())
                                    {
                                        Predict_board.setChess(i, j, Predict_Chess);
                                    }
                                }

                                if (Chosen_Type == " 🐘")
                                {
                                    if (Chess_Chosen.Judge_Elephant_Can_MoveTo(CorX, CorY, i, j, Predict_board) && Chess_Chosen.getSide() != Predict_board.getChess(i, j).getSide())
                                    {
                                        Predict_board.setChess(i, j, Predict_Chess);
                                    }
                                }

                                if (Chosen_Type == " 帅" || Chosen_Type == " 将")
                                {
                                    if (Chess_Chosen.Judge_General_Can_MoveTo(CorX, CorY, i, j, Predict_board) && Chess_Chosen.getSide() != Predict_board.getChess(i, j).getSide())
                                    {
                                        Predict_board.setChess(i, j, Predict_Chess);
                                    }
                                }

                                if (Chosen_Type == " 士" || Chosen_Type == " 仕")
                                {
                                    if (Chess_Chosen.Judge_Advisor_Can_MoveTo(CorX, CorY, i, j, Predict_board) && Chess_Chosen.getSide() != Predict_board.getChess(i, j).getSide())
                                    {
                                        Predict_board.setChess(i, j, Predict_Chess);
                                    }
                                }

                                if (Chosen_Type == " 🚀" || Chosen_Type == " 💣")
                                {
                                    if (Chess_Chosen.Judge_Cannon_Can_MoveTo(CorX, CorY, i, j, Predict_board) && Chess_Chosen.getSide() != Predict_board.getChess(i, j).getSide())
                                    {
                                        Predict_board.setChess(i, j, Predict_Chess);
                                    }
                                }

                                if (Chosen_Type == " 🐎" || Chosen_Type == " 🐕‍🦺")
                                {
                                    if (Chess_Chosen.Judge_Horse_Can_MoveTo(CorX, CorY, i, j, Predict_board) && Chess_Chosen.getSide() != Predict_board.getChess(i, j).getSide())
                                    {
                                        Predict_board.setChess(i, j, Predict_Chess);
                                    }
                                }

                                if (Chosen_Type == " 兵" || Chosen_Type == " 卒")
                                {
                                    if (Chess_Chosen.Judge_Soldier_Can_MoveTo(CorX, CorY, i, j, Predict_board) && Chess_Chosen.getSide() != Predict_board.getChess(i, j).getSide())
                                    {
                                        Predict_board.setChess(i, j, Predict_Chess);
                                    }
                                }

                            }
                        }

                        Predict_board.Display_gameboard();

                        //Once it is predict, we set the predict chess to its initial state
                        for(int i = 0; i < 10; i++)
                        {
                            for(int j = 0; j < 9; j++)
                            {
                                if(Predict_board.getChess(i,j).getSide() == "Predict")
                                {
                                    Predict_board.setChess(i, j,initial);
                                }
                            }
                        }
                    }
                    
                    //If it is not empty, check the Side of the Chess we chosed
                    //If the Side is the CurrentSide
                    //Then Tell the User to Enter the Destination 
                    while (checkUsability_Original(Chess_Chosen, CurrentSide))
                    {
                        Console.WriteLine();
                        Console.WriteLine("Please Enter the Corrdinate of your Destination.");

                        Console.WriteLine("Please Enter the value of X : ");
                        Input_X = Console.ReadLine();
                        Final_CorX = int.Parse(Input_X);

                        Console.WriteLine("Please Enter the value of Y : ");
                        Input_Y = Console.ReadLine();
                        Final_CorY = int.Parse(Input_Y);

                        //Check if the Destination is OK or not
                        //If the Destination has the same side of the chosen chess
                        //Then we print wrong
                        if (!checkUsability_Desination(Chess_Chosen, Final_CorX, Final_CorY, board))
                        {
                            Console.WriteLine();
                            Console.WriteLine("What You Have Chosen is incorrect.");
                        }

                        Console.Clear();

                        //If the Destination is OK
                        //Then we check if the Destination is OK for the type of the Chess Chosen
                        //这里部分棋子的判断出现错误
                        //落子点错误的时候，不会提示出错！！！
                        //游戏结束时的判定还未写入。
                        //这里只检查了我们选择的目的地是不是同类棋子

                        if (checkUsability_Desination(Chess_Chosen, Final_CorX, Final_CorY, board))
                        {
                            //So the Destination is OK to Move
                            //But we need to check that if is OK for the current type chess
                            //So we first get the current Type of the Chess we chosen
                            CurrentType = Chess_Chosen.getType();
                            int Check_If_Is_Runing = 0;

                            //因为我们把红黑棋子分开来了，所以这里不适用于switch，选择使用if语句，较简答易读
                            if (CurrentType == " 🚗" || CurrentType == " 🚓")
                            {
                                if (Chess_Chosen.Judge_Rook_Can_MoveTo(CorX, CorY, Final_CorX, Final_CorY, board))
                                {
                                    //If the Chess can Move to the Destination we Chosed.
                                    board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    Predict_board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    //Set the Original Chess to initial state
                                    board.setChess(CorX, CorY, initial);
                                    Predict_board.setChess(CorX, CorY, initial);
                                    //Display the Board
                                    board.Display_gameboard();
                                    Check_If_Is_Runing = 1;
                                }
                            }

                            if (CurrentType == " 兵" || CurrentType == " 卒")
                            {
                                if (Chess_Chosen.Judge_Soldier_Can_MoveTo(CorX, CorY, Final_CorX, Final_CorY, board))
                                {
                                    //If the Chess can Move to the Destination we Chosed.
                                    board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    Predict_board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    //Set the Original Chess to initial state
                                    board.setChess(CorX, CorY, initial);
                                    Predict_board.setChess(CorX, CorY, initial);
                                    //Display the Board
                                    board.Display_gameboard();
                                    Check_If_Is_Runing = 1;
                                }
                            }

                            if (CurrentType == " 仕" || CurrentType == " 士")
                            {
                                if (Chess_Chosen.Judge_Advisor_Can_MoveTo(CorX, CorY, Final_CorX, Final_CorY, board))
                                {
                                    board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    Predict_board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    board.setChess(CorX, CorY, initial);
                                    Predict_board.setChess(CorX, CorY, initial);
                                    board.Display_gameboard();
                                    Check_If_Is_Runing = 1;
                                }
                            }

                            if (CurrentType == " 帅" || CurrentType == " 将")
                            {
                                if (Chess_Chosen.Judge_General_Can_MoveTo(CorX, CorY, Final_CorX, Final_CorY, board))
                                {
                                    board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    Predict_board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    board.setChess(CorX, CorY, initial);
                                    Predict_board.setChess(CorX, CorY, initial);
                                    board.Display_gameboard();
                                    Check_If_Is_Runing = 1;
                                }
                            }

                            if (CurrentType == " 🐎" || CurrentType == " 🐕‍🦺")
                            {
                                if (Chess_Chosen.Judge_Horse_Can_MoveTo(CorX, CorY, Final_CorX, Final_CorY, board))
                                {
                                    board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    Predict_board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    board.setChess(CorX, CorY, initial);
                                    Predict_board.setChess(CorX, CorY, initial);
                                    board.Display_gameboard();
                                    Check_If_Is_Runing = 1;
                                }
                            }

                            if (CurrentType == " 🚀" || CurrentType == " 💣")
                            {
                                if (Chess_Chosen.Judge_Cannon_Can_MoveTo(CorX, CorY, Final_CorX, Final_CorY, board))
                                {
                                    board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    Predict_board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    board.setChess(CorX, CorY, initial);
                                    Predict_board.setChess(CorX, CorY, initial);
                                    board.Display_gameboard();
                                    Check_If_Is_Runing = 1;
                                }
                            }

                            if (CurrentType == " 🐘")
                            {
                                if (Chess_Chosen.Judge_Elephant_Can_MoveTo(CorX, CorY, Final_CorX, Final_CorY, board))
                                {
                                    board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    Predict_board.setChess(Final_CorX, Final_CorY, Chess_Chosen);
                                    board.setChess(CorX, CorY, initial);
                                    Predict_board.setChess(CorX, CorY, initial);
                                    board.Display_gameboard();
                                    Check_If_Is_Runing = 1;
                                }
                            }

                            if (Check_If_Is_Runing == 0)
                            {
                                Console.WriteLine();
                                Console.WriteLine("The Destination You Have Chosen is Not Correct ! ");
                                Console.WriteLine("Please Enter Again !");
                                break;
                            }
                            RoundCounter += 1;
                        }
                        break;
                    }
                    checkGame_Is_Over(board);

                }
                catch (FormatException)
                {
                    Console.WriteLine();
                    Console.WriteLine("What You Have Entered is the Wrong Format");
                    Console.WriteLine("It should be Digit Only !");
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine();
                    Console.WriteLine("What You Have Entered is the Wrong Index");
                    Console.WriteLine("It should be : X [0,9], Y [0,8]");
                }
            }

        }
    }       
}
