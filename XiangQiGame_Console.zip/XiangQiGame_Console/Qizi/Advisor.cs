﻿using System;
namespace XiangQiGame_Console.Qizi
{
    public class Advisor : ChessPiece
    {
        public Advisor(string Type, bool State, string Side)
            : base(Type,State,Side)
        {}

        
    }
}
