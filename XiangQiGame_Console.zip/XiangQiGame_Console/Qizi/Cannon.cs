﻿using System;
namespace XiangQiGame_Console.Qizi
{
    public class Cannon : ChessPiece
    {
        public Cannon(string Type, bool State, string Side)
            : base(Type, State, Side)
        {}
    }
}
