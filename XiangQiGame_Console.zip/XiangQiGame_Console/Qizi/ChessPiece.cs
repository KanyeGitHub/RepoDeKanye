﻿using System;
namespace XiangQiGame_Console
{
    //ChessPiece is a class
    //With the properities of the Chess
    //And the getter and setter used to modified values
    public class ChessPiece
    {
        string Type;
        bool State;
        string Side;

        public ChessPiece(string Type, bool State, string Side)
        {
            this.Type = Type;
            this.State = State;
            this.Side = Side;
        }


        public bool Judge_Rook_Can_MoveTo(int CorX, int CorY, int Final_CorX, int Final_CorY, ChessBoard board)
        {
            int initial_location;
            int ending_location;
            int loop_Value;

            //By the Properties of the Rook
            //We first check that if the X is the same or Y
            //If Both X and Y are not satisfied, then we return a false
            if (CorX != Final_CorX && CorY != Final_CorY)
            {
                return false;
            }

            //If the CorX is same as the Final_CorX
            //We try to get the Initial and Ending Point of the FOR loop
            //And use the for loop to check the y Asix
            if (CorX == Final_CorX)
            {
                //We get the interval of the for loop area.
                //The interval is like :[CorX, Final_CorX]
                initial_location = CorY < Final_CorY ? CorY : Final_CorY;
                ending_location = CorY > Final_CorY ? CorY : Final_CorY;

                for (loop_Value = initial_location + 1; loop_Value < ending_location; loop_Value++)
                {
                    //If there exists one chess that is no "Lost"
                    //Then we return false, which means that it is not correct
                    if (board.getChess(CorX, loop_Value).getType() != " - " || board.getChess(Final_CorX, ending_location).getSide() == board.getChess(CorX, CorY).getSide())
                    {
                        return false;
                    }
                }
            }

            if (CorY == Final_CorY)
            {
                initial_location = CorX < Final_CorX ? CorX : Final_CorX;
                ending_location = CorX > Final_CorX ? CorX : Final_CorX;

                for (loop_Value = initial_location + 1; loop_Value < ending_location; loop_Value++)
                {
                    if (board.getChess(loop_Value, CorY).getType() != " - " || board.getChess(ending_location, Final_CorY).getSide() == board.getChess(CorX, CorY).getSide())
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public bool Judge_Soldier_Can_MoveTo(int CorX, int CorY, int Final_CorX, int Final_CorY, ChessBoard board)
        {

            //If the Side is Red, It means that chesses are on the above of the board
            //So we use the river to judge if the chess can go or not
            if (board.getChess(CorX, CorY).getSide() == "Red")
            {

                if (CorX < 5 && Final_CorX - CorX != 1)
                {
                    return false;
                }

                if (CorX > 4)
                {

                    if (CorX == Final_CorX && Math.Abs(CorY - Final_CorY) != 1)
                    {
                        return false;
                    }

                    if (CorY == Final_CorY && Math.Abs(CorX - Final_CorX) != 1)
                    {
                        return false;
                    }
                }
            }

                if (board.getChess(CorX, CorY).getSide() == "Black")
                {
                    if (CorX > 4 && CorX - Final_CorX != 1)
                    {
                        return false;
                    }

                    if (CorX < 5)
                    {
                        if (CorX == Final_CorX && Math.Abs(CorY - Final_CorY) != 1)
                        {
                            return false;
                        }

                        if (CorY == Final_CorY && Math.Abs(CorX - Final_CorX) != 1)
                        {
                            return false;
                        }
                    }
                }

                return true;
            }
        
        public bool Judge_Advisor_Can_MoveTo(int CorX, int CorY, int Final_CorX, int Final_CorY, ChessBoard board)
            {
                if (board.getChess(CorX, CorY).getSide() == "Red")
                {
                    if (Final_CorY < 3 || Final_CorY > 5 || Final_CorX > 2)
                    {
                        return false;
                    }
                }
                else
                {
                    if (Final_CorY < 3 || Final_CorY > 5 || Final_CorX < 7)
                    {
                        return false;
                    }
                }

                if (Math.Abs(Final_CorX - CorX) != 1 || Math.Abs(Final_CorY - CorY) != 1)
                {
                    return false;
                }

                return true;
            }

        public bool Judge_General_Can_MoveTo(int CorX, int CorY, int Final_CorX, int Final_CorY, ChessBoard board)
            {
                if (board.getChess(CorX, CorY).getSide() == "Red")
                {
                    if (Final_CorY < 3 || Final_CorY > 5 || Final_CorX > 2)
                    {
                        return false;
                    }
                }
                else
                {
                    if (Final_CorY < 3 || Final_CorY > 5 || Final_CorX < 7)
                    {
                        return false;
                    }
                }

                if ((Final_CorX - CorX) * (Final_CorX - CorX) + (Final_CorY - CorY) + (Final_CorY - CorY) != 1)
                {
                    return false;
                }
                return true;
            }

        public bool Judge_Horse_Can_MoveTo(int CorX, int CorY, int Final_CorX, int Final_CorY, ChessBoard board)
            {
                //马的移动，第一种情况，X为1，Y为2
                if (Math.Abs(CorX - Final_CorX) == 1 && Math.Abs(CorY - Final_CorY) == 2)
                {
                    if (board.getChess(CorX, CorY + (Final_CorY - CorY) / Math.Abs(Final_CorY - CorY)).getSide() != "Lost")
                    {
                        return false;
                    }
                }
                //马的移动，第二种情况，X为2，Y为1
                else if (Math.Abs(CorX - Final_CorX) == 2 && Math.Abs(CorY - Final_CorY) == 1)
                {
                    if (board.getChess(CorX + (Final_CorX - CorX) / Math.Abs(Final_CorX - CorX), CorY).getSide() != "Lost")
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                return true;
            }

        public bool Judge_Elephant_Can_MoveTo(int CorX, int CorY, int Final_CorX, int Final_CorY, ChessBoard board)
            {
                if (board.getChess(CorX, CorY).getSide() == "Red")
                {
                    if (Final_CorX > 4)
                    {
                        return false;
                    }
                }
                else
                {
                    if (Final_CorX < 5)
                    {
                        return false;
                    }
                }

                if ((CorX - Final_CorX) * (CorX - Final_CorX) + (CorY - Final_CorY) * (CorY - Final_CorY) != 8)
                {
                    return false;
                }

                if (board.getChess((CorX + Final_CorX) / 2, (CorY + Final_CorY / 2)).getSide() != "Lost")
                {
                    return false;
                }

                return true;
            }

        //Check and it is Correct
        public bool Judge_Cannon_Can_MoveTo(int CorX, int CorY, int Final_CorX, int Final_CorY, ChessBoard board)
            {
                int initial_location;
                int ending_location;
                int loop_value;
                int Chess_Counter;

                //当X坐标相同时，我们要对Y进行循环，确定循环的起点和终点
                if (CorX == Final_CorX)
                {
                    //确定起点以及重点，引入一个新变量用于计算循环中出现的特定类型棋子个数
                    initial_location = CorY < Final_CorY ? CorY : Final_CorY;
                    ending_location = CorY > Final_CorY ? CorY : Final_CorY;
                    Chess_Counter = 0;

                    //如果有出现不为Lost的棋子，及有一个不为空的棋子，就计数 1
                    for (loop_value = initial_location + 1; loop_value < ending_location; loop_value++)
                    {
                        if (board.getChess(CorX, loop_value).getType() != " - ")
                        {
                            Chess_Counter++;
                        }
                    }

                    //如果路径中间有多个不为空的棋子，这里明显无法走
                    if (Chess_Counter > 1)
                    {
                        return false;
                    }
                }
                //另外一种情况就是Y坐标相等的时候，这里我们对X进行循环，确定循环的起点和重点
                else if (CorY == Final_CorY)
                {
                    //确定起点终点等
                    initial_location = CorX < Final_CorX ? CorX : Final_CorX;
                    ending_location = CorX > Final_CorX ? CorX : Final_CorX;
                    Chess_Counter = 0;

                    for (loop_value = initial_location + 1; loop_value < ending_location; loop_value++)
                    {
                        if (board.getChess(loop_value, CorY).getType() != " - ")
                        {
                            Chess_Counter++;
                        }

                        if (Chess_Counter > 1)
                        {
                            return false;
                        }
                    }
                }
                //如果X，Y都不相等，则返回false
                else
                {
                    return false;
                }

                if (Chess_Counter == 0 && board.getChess(Final_CorX, Final_CorY).getType() != " - ")
                {
                    return false;
                }

                if (Chess_Counter == 1 && board.getChess(Final_CorX, Final_CorY).getType() != " - ")
                {
                    return false;
                }

                return true;
            }

        

        public string getType()
        {
            return this.Type;
        }

        public bool getState()
        {
            return this.State;
        }

        public string getSide()
        {
            return this.Side;
        }

        public void setType(string Type)
        {
            this.Type = Type;
        }

        public void setState(bool State)
        {
            this.State = State;
        }

        public void setSide(string Side)
        {
            this.Side = Side;
        }
        }
}
