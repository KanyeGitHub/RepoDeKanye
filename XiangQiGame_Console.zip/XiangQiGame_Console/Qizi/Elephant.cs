﻿using System;
namespace XiangQiGame_Console.Qizi
{
    public class Elephant : ChessPiece
    {
        public Elephant(string Type, bool State, string Side)
            : base(Type, State, Side)
        {

        }
    }
}
