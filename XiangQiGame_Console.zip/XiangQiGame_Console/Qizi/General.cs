﻿using System;
namespace XiangQiGame_Console.Qizi
{
    public class General : ChessPiece
    {
        public General(string Type, bool State, string Side)
            : base(Type, State, Side)
        {
        }
    }
}
