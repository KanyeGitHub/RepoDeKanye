﻿using System;
namespace XiangQiGame_Console.Qizi
{
    public class Horse : ChessPiece
    {
        public Horse(string Type, bool State, string Side)
            : base(Type, State, Side)
        {

        }
    }
}
