﻿using System;
namespace XiangQiGame_Console.Qizi
{
    public class Rook : ChessPiece
    {
        public Rook(string Type, bool State, string Side)
            : base(Type, State, Side)
        {}

        //现在可以越过自己的棋子 存在错误
        public  bool Judge_Rook_Can_MoveTo(int CorX, int CorY, int Final_CorX, int Final_CorY, ChessBoard board)
        {
            int initial_location;
            int endging_location;
            int loop_Value;

            //By the Properties of the Rook
            //We first check that if the X is the same or Y
            //If Both X and Y are not satisfied, then we return a false
            if(CorX != Final_CorX && CorY != Final_CorY)
            {
                return false;
            }

            //If the CorX is same as the Final_CorX
            //We try to get the Initial and Ending Point of the FOR loop
            //And use the for loop to check the y Asix
            if(CorX == Final_CorX)
            {
                //We get the interval of the for loop area.
                initial_location = CorX < Final_CorX ? CorX : Final_CorX;
                endging_location = CorX > Final_CorX ? CorX : Final_CorX;

                for(loop_Value = initial_location + 1; loop_Value < endging_location; loop_Value ++)
                {
                    //If there exists one chess that is no "Lost"
                    //Then we return false, which means that it is not correct
                    if(board.getChess(CorX,loop_Value).getSide() != "Lost")
                    {
                        return false;
                    }
                }
            }

            if(CorY == Final_CorY)
            {
                initial_location = CorY < Final_CorY ? CorY : Final_CorY;
                endging_location = CorY > Final_CorY ? CorY : Final_CorY;

                for(loop_Value = initial_location + 1; loop_Value < endging_location; loop_Value ++)
                {
                    if(board.getChess(CorY,loop_Value).getSide() != "Lost")
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}
