﻿using System;
namespace XiangQiGame_Console.Qizi
{
    public class Soldier : ChessPiece
    {
        public Soldier(string Type, bool State, string Side)
            : base(Type, State, Side)
        {}
    }
}
