﻿using System;
namespace xiangqi2
{
    public class Board
    {
        public Chess[,] Array = new Chess[10, 9];
        string[,] Array_type = new string[10, 9];
        string[,] Array_side = new string[10, 9];
        public int round = 1;
        public string turn;
        public string symbol;
        public bool select_judge;
        public bool side_judge;

        public bool General_check()
        {
            int General_number = 0;
            bool run = false;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (Array[i, j].type == "将")
                    {
                        General_number = General_number + 1;
                    }
                }
            }
            
            if (General_number == 2)
            {
                run = true;
            }
            return run;
        }

        public void possible_choice(int x11, int y11, string turn)
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    if (Array[x11, y11].side != Array[i, j].side)
                    {
                        switch (Array_type[x11, y11])
                        {
                            case "将":
                                Array[x11, y11].moveJudge(x11, y11, i, j, turn);
                                break;
                            case "士":
                                Array[x11, y11].moveJudge(x11, y11, i, j, turn);
                                break;
                            case "象":
                                int midX = (x11 + i) / 2;
                                int midY = (y11 + j) / 2;
                                string test = Array[midX, midY].type;
                                Array[x11, y11].moveJudge(x11, y11, i, j, turn + "+" + test);
                                break;
                            case "马":
                                int midX2 = (x11 + i) / 2;
                                int midY2 = (y11 + j) / 2;
                                string test1 = Array[midX2, y11].type;
                                string test2 = Array[x11, midY2].type;
                                Array[x11, y11].moveJudge(x11, y11, i, j, turn + "+" + test1 + "+" + test2);
                                break;
                            case "车":
                                int max1 = Math.Max(x11, i);
                                int max2 = Math.Max(y11, j);
                                int min1 = Math.Min(x11, i);
                                int min2 = Math.Min(y11, j);
                                string test3 = "succes";
                                string test4 = "succes";
                                for (int o = min1 + 1; o < max1; o++)
                                {
                                    if (Array[o, y11].type != "empty") { test3 = "false"; }
                                }
                                for (int o = min2 + 1; o < max2; o++)
                                {
                                    if (Array[x11, o].type != "empty") { test4 = "false"; }
                                }
                                Array[x11, y11].moveJudge(x11, y11, i, j, turn + "+" + test3 + "+" + test4);
                                break;
                            case "炮":
                                int max11 = Math.Max(x11, i);
                                int max22 = Math.Max(y11, j);
                                int min11 = Math.Min(x11, i);
                                int min22 = Math.Min(y11, j);
                                int test5 = 0;
                                int test6 = 0;
                                string test7 = "success";
                                string test8 = "success";
                                for (int o = min11 + 1; o < max11; o++)
                                {
                                    if (Array[o, y11].type != "empty" && Array[i, j].type != "empty")
                                    {
                                        test5 = test5 + 1;
                                    }
                                }
                                for (int o = min22 + 1; o < max22; o++)
                                {
                                    if (Array[x11, o].type != "empty" && Array[i, j].type != "empty")
                                    {
                                        test6 = test6 + 1;
                                    }
                                }
                                for (int o = min11 + 1; o <= max11; o++)
                                {
                                    if (Array[o, y11].type != "empty")
                                    {
                                        test7 = "false";
                                    }
                                }
                                for (int o = min22 + 1; o <= max22; o++)
                                {
                                    if (Array[x11, o].type != "empty")
                                    {
                                        test8 = "false";
                                    }
                                }
                                Array[x11, y11].moveJudge(x11, y11, i, j, turn + "+" + test5 + "+" + test6 + "+" + test7 + "+" + test8);
                                break;
                            case "兵":
                                Array[x11, y11].moveJudge(x11, y11, i, j, turn);
                                break;

                        }

                        
                    }
                    if (Array[x11, y11].rule_judge == true)
                    {
                        Array[i, j].possible = true;
                    }
                }
            }

        }


        public bool moveOperation(int x11, int y11, int x22, int y22)
        {
            
            if (Array[x22, y22].side != Array[x11, y11].side && select_judge == true)
            {
                switch (Array_type[x11, y11])
                {
                    case "将":
                        Array[x11, y11].moveJudge(x11, y11, x22, y22, turn);
                        break;
                    case "士":
                        Array[x11, y11].moveJudge(x11, y11, x22, y22, turn);
                        break;
                    case "象":
                        int midX = (x11 + x22) / 2;
                        int midY = (y11 + y22) / 2;
                        string test = Array[midX, midY].type;
                        Array[x11, y11].moveJudge(x11, y11, x22, y22, turn + "+" + test);
                        break;
                    case "马":
                        int midX2 = (x11 + x22) / 2;
                        int midY2 = (y11 + y22) / 2;
                        string test1 = Array[midX2, y11].type;
                        string test2 = Array[x11, midY2].type;
                        Array[x11, y11].moveJudge(x11, y11, x22, y22, turn + "+" + test1 + "+" + test2);
                        break;
                    case "车":
                        int max1 = Math.Max(x11, x22);
                        int max2 = Math.Max(y11, y22);
                        int min1 = Math.Min(x11, x22);
                        int min2 = Math.Min(y11, y22);
                        string test3 = "succes";
                        string test4 = "succes";
                        for (int o = min1 + 1; o < max1; o++)
                        {
                            if (Array[o, y11].type != "empty") { test3 = "false"; }
                        }
                        for (int o = min2 + 1; o < max2; o++)
                        {
                            if (Array[x11, o].type != "empty") { test4 = "false"; }
                        }
                        Array[x11, y11].moveJudge(x11, y11, x22, y22, turn + "+" + test3 + "+" + test4);
                        break;
                    case "炮":
                        int max11 = Math.Max(x11, x22);
                        int max22 = Math.Max(y11, y22);
                        int min11 = Math.Min(x11, x22);
                        int min22 = Math.Min(y11, y22);
                        int test5 = 0;
                        int test6 = 0;
                        string test7 = "success";
                        string test8 = "success";
                        for (int i = min11 + 1; i < max11; i++)
                        {
                            if (Array[i, y11].type != "empty" && Array[x22, y22].type != "empty")
                            {
                                test5 = test5 + 1;
                            }
                        }
                        for (int i = min22 + 1; i < max22; i++)
                        {
                            if (Array[x11, i].type != "empty" && Array[x22, y22].type != "empty")
                            {
                                test6 = test6 + 1;
                            }
                        }
                        for (int i = min11 + 1; i <= max11; i++)
                        {
                            if (Array[i, y11].type != "empty")
                            {
                                test7 = "false";
                            }
                        }
                        for (int i = min22 + 1; i <= max22; i++)
                        {
                            if (Array[x11, i].type != "empty")
                            {
                                test8 = "false";
                            }
                        }
                        Array[x11, y11].moveJudge(x11, y11, x22, y22, turn + "+" + test5 + "+" + test6 + "+" + test7 + "+" + test8);
                        break;
                    case "兵":
                        Array[x11, y11].moveJudge(x11, y11, x22, y22, turn);
                        break;
                    case "B":
                        Array[x11, y11].moveJudge(x11, y11, x22, y22, "");
                        break;
                }
                side_judge = true;
            }
            else
            {
                side_judge = false;
            }
            return side_judge;
        }


        public void move1(int x11, int y11, int x22, int y22)
        {
            switch (Array_type[x11, y11])
            {
                case "将":
                    Array[x22, y22] = new chess_General(turn); ;
                    break;
                case "士":
                    Array[x22, y22] = new chess_Assistant(turn);
                    break;
                case "象":
                    Array[x22, y22] = new chess_Elephant(turn);
                    break;
                case "马":
                    Array[x22, y22] = new chess_Horse(turn);
                    break;
                case "车":
                    Array[x22, y22] = new chess_Rook(turn);
                    break;
                case "炮":
                    Array[x22, y22] = new chess_Cannon(turn);
                    break;
                case "兵":
                    Array[x22, y22] = new chess_Solider(turn);
                    break;
            }
            Array[x11, y11] = new chess_Blank();
            Array[x11, y11].rule_judge = false;
            round = round + 1;
            Console.WriteLine("Great! You moved " + turn + " " + Array[x22, y22].type + " successfully");
        }


        public bool chess_select(int x, int y)
        {
            if (Array[x, y].side == turn)
            {
                select_judge = true;
            }
            else { select_judge = false; }
            return select_judge;
        }


        public void getTurn(int round)
        {
            if (round % 2 == 0) { turn = "Black"; }
            else if (round % 2 == 1) { turn = "Red"; }
        }



        public void setBoard()
        {
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    Array[i, j] = new chess_Blank();
                }
            }
            Array[0, 4] = new chess_General("Black");
            Array[9, 4] = new chess_General("Red");
            Array[0, 3] = new chess_Assistant("Black");
            Array[0, 5] = new chess_Assistant("Black");
            Array[9, 3] = new chess_Assistant("Red");
            Array[9, 5] = new chess_Assistant("Red");
            Array[0, 2] = new chess_Elephant("Black");
            Array[0, 6] = new chess_Elephant("Black");
            Array[9, 2] = new chess_Elephant("Red");
            Array[9, 6] = new chess_Elephant("Red");
            Array[0, 1] = new chess_Horse("Black");
            Array[0, 7] = new chess_Horse("Black");
            Array[9, 1] = new chess_Horse("Red");
            Array[9, 7] = new chess_Horse("Red");
            Array[0, 0] = new chess_Rook("Black");
            Array[0, 8] = new chess_Rook("Black");
            Array[9, 0] = new chess_Rook("Red");
            Array[9, 8] = new chess_Rook("Red");
            Array[2, 1] = new chess_Cannon("Black");
            Array[2, 7] = new chess_Cannon("Black");
            Array[7, 1] = new chess_Cannon("Red");
            Array[7, 7] = new chess_Cannon("Red");
            Array[3, 0] = new chess_Solider("Black");
            Array[3, 2] = new chess_Solider("Black");
            Array[3, 4] = new chess_Solider("Black");
            Array[3, 6] = new chess_Solider("Black");
            Array[3, 8] = new chess_Solider("Black");
            Array[6, 0] = new chess_Solider("Red");
            Array[6, 2] = new chess_Solider("Red");
            Array[6, 4] = new chess_Solider("Red");
            Array[6, 6] = new chess_Solider("Red");
            Array[6, 8] = new chess_Solider("Red");
        }



        public void print()
        {
            getTurn(round);

            Console.WriteLine("Black side");

            Console.WriteLine("x 0 1 2 3 4 5 6 7 8 y");

            for (int i = 0; i < 10; i++)
            {

                Console.Write(i + " ");

                for (int j = 0; j < 9; j++)
                {
                    Array_type[i, j] = Array[i, j].type;
                    Array_side[i, j] = Array[i, j].side;
                    if (Array_type[i, j] == "empty" && i == 1 && j == 4)
                    {
                        symbol = "米";
                    }
                    else if (Array_type[i, j] == "empty" && i == 8 && j == 4)
                    {
                        symbol = "米";
                    }
                    else if (Array_type[i, j] == "empty" && i == 0 && j == 0)
                    {
                        symbol = "┌─";
                    }
                    else if (Array_type[i, j] == "empty" && i == 0 && j == 8)
                    {
                        symbol = "┐";
                    }
                    else if (Array_type[i, j] == "empty" && i == 9 && j == 0)
                    {
                        symbol = "└─";
                    }
                    else if (Array_type[i, j] == "empty" && i == 9 && j == 8)
                    {
                        symbol = "┘";
                    }
                    else if (Array_type[i, j] == "empty" && i == 0)
                    {
                        symbol = "┬─";
                    }
                    else if (Array_type[i, j] == "empty" && i == 9)
                    {
                        symbol = "┴─";
                    }
                    else if (Array_type[i, j] == "empty" && j == 8)
                    {
                        symbol = "┤";
                    }
                    else if (Array_type[i, j] == "empty" && j == 0)
                    {
                        symbol = "├─";
                    }
                    else if (Array_type[i, j] == "empty" && i == 4)
                    {
                        symbol = "┴─";
                    }
                    else if (Array_type[i, j] == "empty" && i == 5)
                    {
                        symbol = "┬─";
                    }
                    else if (Array_type[i, j] == "empty")
                    {
                        symbol = "┼─";
                    }
                    else if (Array[i, j].side == "Red" && Array_type[i, j] == "将")
                    {
                        symbol = "帅";
                    }
                    else if (Array[i, j].side == "Black" && Array_type[i, j] == "兵")
                    {
                        symbol = "卒";
                    }
                    else { symbol = Array_type[i, j]; }
                    if (Array[i, j].possible == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write(symbol);
                        Console.ForegroundColor = ConsoleColor.Black;
                        Array[i, j].possible = false;
                    }
                    else if (Array_side[i, j] == "Red")
                    {

                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write(symbol);
                        Console.ForegroundColor = ConsoleColor.Black;


                    }
                    else if (Array_side[i, j] == "Black")
                    {

                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.Write(symbol);
                        Console.ForegroundColor = ConsoleColor.Black;
                    }

                    else { Console.Write(symbol); }
                }
                Console.WriteLine("");
                if (i == 4) { Console.WriteLine("  │  楚河   汉界  │"); }
            }
            Console.WriteLine("Red side");

        }
    }
}
