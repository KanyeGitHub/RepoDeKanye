﻿using System;
namespace xiangqi2
{

    public abstract class Chess
    {

        
        
       
        public static string  Red,Black;
        public string type;
        public string side;
        public int start_x,  start_y,  destination_x, destination_y;
        public bool rule_judge;
        public bool possible;
        
        public Chess(string unknown,string unside)
        {
            type = unknown;
            side = unside;
        }
        public abstract void moveJudge(int start_x, int start_y, int destination_x, int destination_y,string side);

        
       




    }
}
