﻿using System;

namespace xiangqi2
{
    class Program
    {
        static void Main(string[] args)
        {
            Board Game = new Board();
            int stoptimer = 1;
            
            Console.WriteLine("Welcome to XiangQi Game!");


            Game.setBoard();


            for (int p = 0; p < stoptimer; p++)
            {
                if (Game.General_check())
                {
                    Game.print();
                    
                    Console.Write("Now " + Game.turn + " turn!" );
                    Console.WriteLine("Please choose one chess:");
                    string input = Console.ReadLine();
                    string[] start = input.Split();
                    string x1 = start[0];
                    string y1 = start[1];
                    int x11 = int.Parse(x1);
                    int y11 = int.Parse(y1);
                    Game.chess_select(x11, y11);
                    if (Game.chess_select(x11, y11))
                    {
                        Game.possible_choice(x11, y11, Game.turn);
                        Game.print();
                        Console.WriteLine("Please choose where you want to go:");
                        string input2 = Console.ReadLine();
                        string[] destination = input2.Split();
                        string x2 = destination[0];
                        string y2 = destination[1];
                        int x22 = int.Parse(x2);
                        int y22 = int.Parse(y2);
                        Game.moveOperation(x11, y11, x22, y22);
                        if (Game.moveOperation(x11, y11, x22, y22))
                        {
                            if (Game.Array[x11, y11].rule_judge)
                            {
                                Game.move1(x11, y11, x22, y22);
                                
                            }
                            else { Console.WriteLine("Sorry! It is not obey the rules."); }
                        }
                        else { Console.WriteLine("Sorry! You can't eat your ownn chess."); }
                    }
                    else {
                        Console.WriteLine("Sorry! There is no your Chess."); }
                    stoptimer = stoptimer + 1;
                }
                else
                {
                    Game.print();
                    int finishRounnd=Game.round - 1;
                    Game.getTurn(finishRounnd);
                    Console.Write("Game over!" + Game.turn + " side won this game!");
                    continue;
                }
            }
            

            


























        }
    }
}

