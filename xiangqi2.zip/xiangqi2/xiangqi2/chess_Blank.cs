﻿using System;
namespace xiangqi2
{

    public class chess_Blank : Chess
    {
        public chess_Blank()
            : base("empty", "") { }

        public override void moveJudge(int start_x, int start_y, int destination_x, int destination_y,string side)
        {
            
            this.start_x = start_x;
            this.start_y = start_y;
            this.destination_x = destination_x;
            this.destination_y = destination_y;
        }
        
    }

}
