﻿using System;
namespace xiangqi2
{
    public class chess_Cannon:Chess
    {
        public chess_Cannon(string side)
            : base("炮", side) { }
        public override void moveJudge(int start_x, int start_y, int destination_x, int destination_y, string side)
        {
            this.side = side;
            string[] start = side.Split("+");
            string part1 = start[1];
            string part2 = start[2];
            string part3 = start[3];
            string part4 = start[4];
            this.start_x = start_x;
            this.start_y = start_y;
            this.destination_x = destination_x;
            this.destination_y = destination_y;
            if (start_x==destination_x &&part2 == "1")
            {
                rule_judge = true;
            }
            else if (start_y == destination_y && part1 == "1")
            {
                rule_judge = true;
            }
            else if(start_x==destination_x&&part4=="success")
            {
                rule_judge = true;
            }
            else if (start_y == destination_y && part3 == "success")
            {
                rule_judge = true;
            }
            else { 
                rule_judge = false;
            }

        }

    }
}
