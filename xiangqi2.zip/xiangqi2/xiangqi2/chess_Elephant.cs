﻿using System;
namespace xiangqi2
{
    public class chess_Elephant:Chess
    {
        public chess_Elephant(string side)
         :base("象", side) { }
        public override void moveJudge(int start_x, int start_y, int destination_x, int destination_y, string side)
        {
            
            string[] start = side.Split("+");
            string part0 = start[0];
            string part1= start[1];
            this.start_x = start_x;
            this.start_y = start_y;
            this.destination_x = destination_x;
            this.destination_y = destination_y;
            int absoluteX = Math.Abs(destination_x - start_x);
            int absoluteY = Math.Abs(destination_y - start_y);
            if (part0 == "Red" && start_x >= 5 && absoluteX == 2 && absoluteY ==2&&part1=="empty")
            {
                rule_judge = true;
            }
            else if (part0 == "Black" && start_x < 5 && absoluteX == 2 && absoluteY == 2&&part1== "empty")
            {
                rule_judge = true;
            }
            else
            {
                rule_judge = false;
            }
        }
    }
}
