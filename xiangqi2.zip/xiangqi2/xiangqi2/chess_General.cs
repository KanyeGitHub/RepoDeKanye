﻿using System;
namespace xiangqi2
{
    public class chess_General : Chess
    {

        public chess_General(string side)
            : base("将", side) { }

        public override void moveJudge(int start_x, int start_y, int destination_x, int destination_y, string side)
        {
            this.start_x = start_x;
            this.start_y = start_y;
            this.destination_x = destination_x;
            this.destination_y = destination_y;
            int absoluteX = Math.Abs(destination_x - start_x);
            int absoluteY = Math.Abs(destination_y - start_y);
            int absoluteGo = absoluteX + absoluteY;

            if (destination_x < 3 && destination_y >= 3 && destination_y <= 5 && absoluteX <= 1 && absoluteY <= 1 && absoluteGo == 1 && side == "Black")
            {
                rule_judge = true;
                
            }
            else if (destination_x > 6 && destination_y >= 3 && destination_y <= 5 && absoluteX <= 1 && absoluteY <= 1 && absoluteGo == 1 && side == "Red")
            {
                rule_judge = true;
            }
            else
            {
                rule_judge = false;
            }
        }
        

    }
}
