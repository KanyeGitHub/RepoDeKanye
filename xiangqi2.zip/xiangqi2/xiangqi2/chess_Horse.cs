﻿using System;
namespace xiangqi2
{
    public class chess_Horse:Chess
    {
        public chess_Horse(string side)
       : base("马", side) { }
        public override void moveJudge(int start_x, int start_y, int destination_x, int destination_y, string side)
        {
            
            string[] start = side.Split("+");
            string part1 = start[0];
            string part2 = start[1];
            string part3 = start[2];
            this.start_x = start_x;
            this.start_y = start_y;
            this.destination_x = destination_x;
            this.destination_y = destination_y;
            int absoluteX = Math.Abs(destination_x - start_x);
            int absoluteY = Math.Abs(destination_y - start_y);
            if (absoluteX == 2 && absoluteY == 1 && part2 == "empty")
            {
                rule_judge = true;
            }
            else if (absoluteX == 1 && absoluteY == 2 && part3 == "empty")
            {
                rule_judge = true;
            }
            else
            {
                rule_judge = false;
            }
        }
    }
}
