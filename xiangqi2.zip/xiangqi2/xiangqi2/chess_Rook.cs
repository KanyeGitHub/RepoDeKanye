﻿using System;
namespace xiangqi2
{
    public class chess_Rook:Chess
    {
        public chess_Rook(string side)
        : base("车", side) { }
        public override void moveJudge(int start_x, int start_y, int destination_x, int destination_y,string side)
        {
            
            string[] start = side.Split("+");
            string part1 = start[1];
            string part2 = start[2];
            this.start_x = start_x;
            this.start_y = start_y;
            this.destination_x = destination_x;
            this.destination_y = destination_y;
            if (start_x == destination_x && part2 != "false")
            {
                rule_judge = true;
            }
            else if (start_y == destination_y && part1 != "false")
            {
                rule_judge = true;
            }
            else
            {
                rule_judge = false;
            }

        }
    }
}
