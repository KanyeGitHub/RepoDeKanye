﻿using System;
namespace xiangqi2
{
    public class chess_Solider:Chess
    {
        public chess_Solider(string side)
            : base("兵", side) { }
        public override void moveJudge(int start_x, int start_y, int destination_x, int destination_y, string side)
        {

            this.start_x = start_x;
            this.start_y = start_y;
            this.destination_x = destination_x;
            this.destination_y = destination_y;
            int absoluteX = Math.Abs(destination_x - start_x);
            int absoluteY = Math.Abs(destination_y - start_y);
            int absoluteGo = absoluteX + absoluteY;
            if (side == "Red" && start_x < 5 && absoluteX<=1&& start_x-destination_x>=0&&absoluteY <= 1 && absoluteGo == 1)
            {
                rule_judge = true;  
            }
            else if (side == "Black" && start_x > 4 && absoluteX <= 1 && absoluteY <= 1 && absoluteGo == 1&&destination_x-start_x>=0)
            {
                rule_judge = true;
            }
            else if (side == "Red" && start_x >= 5 && absoluteX <= 1 && start_x - destination_x >= 0 && absoluteGo == 1&&absoluteY==0)
            {
                rule_judge = true;
            }
            else if (side == "Black" && start_x < 5 && absoluteX <= 1 && destination_x-start_x >= 0 && absoluteGo == 1 && absoluteY == 0)
            {
                rule_judge = true;
            }
            else
            {
                rule_judge = false;
               
            }
        }
    }
}
